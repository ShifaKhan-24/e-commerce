
export const HomeComponent=()=>{
    return(
        <div className="container">
            <h2>Home</h2>
        </div>
    )
}