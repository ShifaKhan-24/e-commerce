
export const FooterComponent =()=>{
    return(
        <div>
            <footer className="footer bg-dark fixed-bottom">
                <span className="text-muted">All rights Reserver @nirmaluni.com</span>
            </footer>
        </div>
    )
        
    }